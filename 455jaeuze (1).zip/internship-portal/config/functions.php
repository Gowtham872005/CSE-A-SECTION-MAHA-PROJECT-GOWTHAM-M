<?php
if (session_status() === PHP_SESSION_NONE) session_start();

const STATUSES = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected', 'Rejected'];

function e($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void {
    header('Location: ' . BASE_URL . $path);
    exit;
}

function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function dashboard_path(): string {
    return ($_SESSION['role'] ?? '') === 'company'
        ? '/company/dashboard.php'
        : '/student/dashboard.php';
}

// Call at the top of protected pages: require_login('student') / ('company')
function require_login(string $role): void {
    if (!is_logged_in()) {
        flash('error', 'Please login first.');
        redirect('/login.php');
    }
    if ($_SESSION['role'] !== $role) redirect(dashboard_path());
}

// students.id / companies.id for the logged-in user
function student_id(PDO $pdo): int {
    $s = $pdo->prepare('SELECT id FROM students WHERE user_id = ?');
    $s->execute([$_SESSION['user_id']]);
    return (int)$s->fetchColumn();
}

function company_id(PDO $pdo): int {
    $s = $pdo->prepare('SELECT id FROM companies WHERE user_id = ?');
    $s->execute([$_SESSION['user_id']]);
    return (int)$s->fetchColumn();
}

function flash(string $type, string $msg): void {
    $_SESSION['flash'][] = [$type, $msg];
}

// "Under Review" -> "badge s-under-review"  (matches css/style.css)
function status_class(string $status): string {
    return 'badge s-' . strtolower(str_replace(' ', '-', $status));
}

function render_header(string $title = ''): void {
    $b = BASE_URL;
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width, initial-scale=1">'
       . '<title>' . e($title) . ' - Internship Portal</title>'
       . '<link rel="stylesheet" href="' . $b . '/css/style.css"></head><body>';
    echo '<header class="topbar"><a class="brand" href="' . $b . '/index.php">Internship Portal</a><nav>';
    if (is_logged_in()) {
        if ($_SESSION['role'] === 'student') {
            echo '<a href="' . $b . '/student/dashboard.php">Dashboard</a>'
               . '<a href="' . $b . '/student/internships.php">Internships</a>'
               . '<a href="' . $b . '/student/applications.php">My applications</a>'
               . '<a href="' . $b . '/student/profile.php">Profile</a>';
        } else {
            echo '<a href="' . $b . '/company/dashboard.php">Dashboard</a>'
               . '<a href="' . $b . '/company/add_internship.php">Add internship</a>'
               . '<a href="' . $b . '/company/internships.php">My internships</a>'
               . '<a href="' . $b . '/company/applicants.php">Applicants</a>';
        }
        echo '<a href="' . $b . '/logout.php">Logout</a>';
    } else {
        echo '<a href="' . $b . '/login.php">Login</a><a href="' . $b . '/register.php">Register</a>';
    }
    echo '</nav></header><main class="container">';
    foreach ($_SESSION['flash'] ?? [] as [$type, $msg]) {
        echo '<div class="alert ' . e($type) . '">' . e($msg) . '</div>';
    }
    unset($_SESSION['flash']);
}

function render_footer(): void {
    echo '</main><footer class="footer">Internship Portal &middot; Web Technology project</footer>'
       . '<script src="' . BASE_URL . '/js/validation.js"></script></body></html>';
}
