<?php

$host     = "db01.dbhost.dev";
$port     = 5051;
$dbname   = "db_455965s2j";
$username = "user_455965s2j";
$password = "p455965s2j";


if (!defined('BASE_URL')) {
    $h = $_SERVER['HTTP_HOST'] ?? '';
    
    define('BASE_URL', str_contains($h, '-5300.') ? '/proxy/8080' : '');
}
try {
    $pdo = new PDO(
        "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4",
        $username,
        $password
    );
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


require_once __DIR__ . '/functions.php';
