# Internship Portal

Web Technology project built with PHP, MySQL, HTML, CSS and JavaScript.

## Roles and features
- **Student:** register, login, create profile, add skills, upload resume, search internships, apply, track application
- **Company:** register, login, add internship, view applicants, shortlist, reject, update status

Application workflow: Applied > Under Review > Shortlisted > Interview > Selected / Rejected

## Setup (XAMPP / WAMP)
1. Copy the `internship-portal` folder into `htdocs`.
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database.sql` (it creates the `internship_portal` database).
4. Check `config/database.php` (default user `root`, empty password).
5. Open http://localhost/internship-portal/

## Setup (Docker)
    docker compose up --build
Then open http://localhost:8080/

## Setup (Linux terminal, MySQL already running)
    mysql -u root -p < database.sql
    php -S localhost:8000 -t .
`BASE_URL` is empty by default, so this works as is. For XAMPP set it to `/internship-portal` in `config/database.php`.

## Database tables
users, students, companies, internships, applications, password_resets

## Folder structure
    internship-portal/
    ├── index.php, login.php, register.php, logout.php
    ├── forgot_password.php, reset_password.php
    ├── student/    dashboard, profile, internships, apply, applications
    ├── company/    dashboard, add_internship, internships, applicants
    ├── config/     database.php
    ├── css/        style.css
    ├── js/         validation.js
    ├── uploads/    resumes/
    └── database.sql

## Two workspaces (MySQL in one, PHP in another)
See `mysql_setup.sql`, then put the MySQL workspace host in `$DB_HOST` of `config/database.php` and open `test_db.php` to check the connection.
