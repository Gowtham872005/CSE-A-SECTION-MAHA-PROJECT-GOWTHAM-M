<?php
require_once 'config/database.php';

$token = $_GET['token'] ?? $_POST['token'] ?? '';
$stmt = $pdo->prepare('SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW()');
$stmt->execute([$token]);
$reset = $stmt->fetch();

$error = '';
if ($reset && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';
    if (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')
            ->execute([password_hash($password, PASSWORD_DEFAULT), $reset['user_id']]);
        $pdo->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$reset['user_id']]);
        flash('success', 'Password changed. Please login.');
        redirect('/login.php');
    }
}
render_header('Reset password');
?>
<div class="form-box">
  <h2>Reset password</h2>
  <?php if (!$reset): ?>
    <div class="alert error">This reset link is invalid or has expired.</div>
    <p><a href="forgot_password.php">Request a new link</a></p>
  <?php else: ?>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="post" class="js-validate" novalidate>
      <input type="hidden" name="token" value="<?= e($token) ?>">
      <label>New password <input type="password" name="password" minlength="6" required></label>
      <label>Confirm password <input type="password" name="confirm" required></label>
      <button class="btn" type="submit">Save new password</button>
    </form>
  <?php endif; ?>
</div>
<?php render_footer(); ?>
