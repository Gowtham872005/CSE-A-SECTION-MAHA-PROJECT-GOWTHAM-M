-- Run this ONCE on the workspace where MySQL is installed, as root:
--   sudo mysql < mysql_setup.sql
-- Then import the tables:
--   sudo mysql internship_portal < database.sql
CREATE DATABASE IF NOT EXISTS internship_portal CHARACTER SET utf8mb4;
CREATE USER IF NOT EXISTS 'portal'@'%' IDENTIFIED BY 'Portal@2026';
GRANT ALL PRIVILEGES ON internship_portal.* TO 'portal'@'%';
FLUSH PRIVILEGES;
