<?php
require_once 'config/database.php';

$link = '';
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $uid = $stmt->fetchColumn();

    if ($uid) {
        $token = bin2hex(random_bytes(32));
        $pdo->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$uid]);
        $pdo->prepare('INSERT INTO password_resets (user_id, token, expires_at) VALUES (?,?, DATE_ADD(NOW(), INTERVAL 1 HOUR))')
            ->execute([$uid, $token]);
        
        $link = BASE_URL . '/reset_password.php?token=' . $token;
    }
    $message = 'If this email is registered, a reset link has been created.';
}
render_header('Forgot password');
?>
<div class="form-box">
  <h2>Forgot password</h2>
  <?php if ($message): ?><div class="alert success"><?= e($message) ?></div><?php endif; ?>
  <?php if ($link): ?>
    <p>Demo reset link (valid for 1 hour):</p>
    <p><a href="<?= e($link) ?>">Reset my password</a></p>
  <?php endif; ?>
  <form method="post" class="js-validate" novalidate>
    <label>Registered email <input type="email" name="email" required></label>
    <button class="btn" type="submit">Get reset link</button>
  </form>
  <p class="muted"><a href="login.php">Back to login</a></p>
</div>
<?php render_footer(); ?>
