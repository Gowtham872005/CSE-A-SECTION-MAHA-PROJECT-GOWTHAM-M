<?php
require_once '../config/database.php';
require_login('student');
$sid = student_id($pdo);

$stmt = $pdo->prepare('SELECT a.*, i.title, c.company_name FROM applications a
                       JOIN internships i ON i.id = a.internship_id
                       JOIN companies c ON c.id = i.company_id
                       WHERE a.student_id = ? ORDER BY a.applied_at DESC');
$stmt->execute([$sid]);
$apps = $stmt->fetchAll();

$steps = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected'];
render_header('My Applications');
?>
<h2>My applications</h2>
<?php if (!$apps): ?>
  <p class="muted">You have not applied yet. <a href="internships.php">Browse internships</a>.</p>
<?php endif; ?>
<?php foreach ($apps as $a): ?>
  <div class="card">
    <div class="row">
      <div>
        <h3><?= e($a['title']) ?></h3>
        <p class="muted"><?= e($a['company_name']) ?> &middot; Applied on <?= e(date('d M Y', strtotime($a['applied_at']))) ?></p>
      </div>
      <span class="<?= status_class($a['status']) ?>"><?= e($a['status']) ?></span>
    </div>
    <?php if ($a['status'] === 'Rejected'): ?>
      <p class="muted">The company did not move forward with this application.</p>
    <?php else: ?>
      <?php $at = array_search($a['status'], $steps); ?>
      <ol class="tracker">
        <?php foreach ($steps as $n => $s): ?>
          <li class="<?= $n <= $at ? 'done' : '' ?>"><?= e($s) ?></li>
        <?php endforeach; ?>
      </ol>
    <?php endif; ?>
  </div>
<?php endforeach; ?>
<?php render_footer(); ?>
