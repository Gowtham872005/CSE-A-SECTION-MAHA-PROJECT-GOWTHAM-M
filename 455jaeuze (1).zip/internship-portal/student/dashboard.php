<?php
require_once '../config/database.php';
require_login('student');
$sid = student_id($pdo);

$counts = array_fill_keys(STATUSES, 0);
$q = $pdo->prepare('SELECT status, COUNT(*) c FROM applications WHERE student_id = ? GROUP BY status');
$q->execute([$sid]);
foreach ($q->fetchAll() as $r) $counts[$r['status']] = $r['c'];
$total = array_sum($counts);

$p = $pdo->prepare('SELECT phone, college, skills, resume FROM students WHERE id = ?');
$p->execute([$sid]);
$profile = $p->fetch();
$incomplete = !$profile['college'] || !$profile['skills'] || !$profile['resume'];

render_header('Dashboard');
?>
<h2>Welcome, <?= e($_SESSION['name']) ?></h2>
<?php if ($incomplete): ?>
  <div class="alert info">Your profile is incomplete. <a href="profile.php">Add college, skills and resume</a> before applying.</div>
<?php endif; ?>
<div class="grid stats">
  <div class="card"><h3><?= $total ?></h3><p class="muted">Total applications</p></div>
  <div class="card"><h3><?= $counts['Under Review'] ?></h3><p class="muted">Under review</p></div>
  <div class="card"><h3><?= $counts['Shortlisted'] + $counts['Interview'] ?></h3><p class="muted">Shortlisted / interview</p></div>
  <div class="card"><h3><?= $counts['Selected'] ?></h3><p class="muted">Selected</p></div>
</div>
<p><a class="btn" href="internships.php">Search internships</a>
   <a class="btn ghost" href="applications.php">Track applications</a></p>
<?php render_footer(); ?>
