<?php
require_once '../config/database.php';
require_login('company');
$cid = company_id($pdo);

$errors = [];
$f = ['title' => '', 'description' => '', 'skills_required' => '', 'location' => '', 'stipend' => '', 'duration' => '', 'deadline' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($f as $k => $_) $f[$k] = trim($_POST[$k] ?? '');

    if ($f['title'] === '') $errors[] = 'Title is required.';
    if ($f['description'] === '') $errors[] = 'Description is required.';
    if ($f['deadline'] === '' || strtotime($f['deadline']) < strtotime('today')) $errors[] = 'Deadline must be today or later.';

    if (!$errors) {
        $pdo->prepare('INSERT INTO internships (company_id, title, description, skills_required, location, stipend, duration, deadline)
                       VALUES (?,?,?,?,?,?,?,?)')
            ->execute([$cid, $f['title'], $f['description'], $f['skills_required'], $f['location'], $f['stipend'], $f['duration'], $f['deadline']]);
        flash('success', 'Internship posted.');
        redirect('/company/internships.php');
    }
}
render_header('Add Internship');
?>
<div class="form-box wide">
  <h2>Add internship</h2>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="js-validate" novalidate>
    <label>Title <input type="text" name="title" value="<?= e($f['title']) ?>" required></label>
    <label>Description <textarea name="description" rows="5" required><?= e($f['description']) ?></textarea></label>
    <label>Skills required (comma separated)
      <input type="text" name="skills_required" value="<?= e($f['skills_required']) ?>" placeholder="PHP, MySQL">
    </label>
    <label>Location <input type="text" name="location" value="<?= e($f['location']) ?>" placeholder="Chennai / Remote"></label>
    <label>Stipend <input type="text" name="stipend" value="<?= e($f['stipend']) ?>" placeholder="e.g. 5000/month"></label>
    <label>Duration <input type="text" name="duration" value="<?= e($f['duration']) ?>" placeholder="e.g. 2 months"></label>
    <label>Application deadline <input type="date" name="deadline" value="<?= e($f['deadline']) ?>" required></label>
    <button class="btn" type="submit">Post internship</button>
  </form>
</div>
<?php render_footer(); ?>
