<?php
require_once '../config/database.php';
require_login('company');
$cid = company_id($pdo);

$one = function ($sql) use ($pdo, $cid) { $s = $pdo->prepare($sql); $s->execute([$cid]); return $s->fetchColumn(); };
$jobs  = $one('SELECT COUNT(*) FROM internships WHERE company_id = ?');
$apps  = $one('SELECT COUNT(*) FROM applications a JOIN internships i ON i.id = a.internship_id WHERE i.company_id = ?');
$short = $one("SELECT COUNT(*) FROM applications a JOIN internships i ON i.id = a.internship_id WHERE i.company_id = ? AND a.status = 'Shortlisted'");
$new   = $one("SELECT COUNT(*) FROM applications a JOIN internships i ON i.id = a.internship_id WHERE i.company_id = ? AND a.status = 'Applied'");

render_header('Dashboard');
?>
<h2>Welcome, <?= e($_SESSION['name']) ?></h2>
<div class="grid stats">
  <div class="card"><h3><?= $jobs ?></h3><p class="muted">Internships posted</p></div>
  <div class="card"><h3><?= $apps ?></h3><p class="muted">Total applicants</p></div>
  <div class="card"><h3><?= $new ?></h3><p class="muted">New, not reviewed</p></div>
  <div class="card"><h3><?= $short ?></h3><p class="muted">Shortlisted</p></div>
</div>
<p><a class="btn" href="add_internship.php">Add internship</a>
   <a class="btn ghost" href="applicants.php">View applicants</a></p>
<?php render_footer(); ?>
